# Samples directory

Sample applications that are not run as part of the unit tests

The ADO sample is a wrapper for the ADO classes. This demonstrates how
to write JACOB wrappers.

The applet sample shows how to use JACOB in an applet. The trick is to
initialize and use the COM object in the same thread.

