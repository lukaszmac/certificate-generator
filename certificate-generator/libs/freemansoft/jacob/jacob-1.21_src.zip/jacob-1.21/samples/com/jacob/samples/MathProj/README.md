A Simple VB COM DLL that exposes two methods and raises events.

The dll must be registered with your system
```
Run --> regsvr32 <path>\com\jacob\test\MathProj\MathTest.dll
```